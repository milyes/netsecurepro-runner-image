#!/bin/bash

# Nom du projet (personnalisable)
PROJECT_NAME="netsecurepro-runner-image"
ZIP_NAME="$PROJECT_NAME.zip"

echo "[+] Création de l'archive ZIP : $ZIP_NAME"
zip -r "$ZIP_NAME" . -x "*.git*" "__pycache__/*"

# Vérifie si le zip a bien été créé
if [ -f "$ZIP_NAME" ]; then
    echo "[✓] Archive créée avec succès : $ZIP_NAME"

    # Ajoute et pousse le fichier ZIP sur GitHub si besoin
    git add "$ZIP_NAME"
    git commit -m "Ajout de l'archive $ZIP_NAME"
    git push

    echo "[✓] Archive poussée sur GitHub (si tout est configuré)"
else
    echo "[!] Échec de la création du fichier ZIP"
fi
